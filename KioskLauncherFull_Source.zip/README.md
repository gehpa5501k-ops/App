# Kiosk Launcher (Android Studio source)

This is a starter project for a consent-based kiosk launcher on a dedicated/managed Android device.

## Features
- Lists launchable installed apps.
- Admin PIN (default 2468) opens app-selection mode.
- Admin can choose which installed apps appear in the launcher.
- Device Owner can allow-list packages and start Android Lock Task mode.
- Requests Device Admin for demonstration, but Device Admin alone is NOT Device Owner.
- Boot receiver opens the app after BOOT_COMPLETED where Android permits it.

## Build
Open this folder in Android Studio and let Gradle sync. Build APK from Build > Build APK(s).

## Device Owner setup
For a dedicated test device, Android Device Owner provisioning is normally done during initial setup or with ADB on a freshly reset test device. Follow official Android enterprise provisioning documentation. Do not run provisioning on a phone containing data you need; it can require factory reset.

## Important limitations
- No app can run while the device is physically powered off.
- Android may restrict background launches after reboot; OEM behavior varies.
- This project does not block power-off, recovery, factory reset, or every system escape path.
- Device Owner/Lock Task is intended for devices you own or are authorized to manage.
- For production, add stronger PIN storage, audit logging, accessibility testing, and explicit admin recovery procedures.
