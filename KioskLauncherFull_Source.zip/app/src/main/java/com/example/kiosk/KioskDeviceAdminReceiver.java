package com.example.kiosk;

import android.app.admin.DeviceAdminReceiver;

public class KioskDeviceAdminReceiver extends DeviceAdminReceiver {
}
