package com.example.kiosk;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String PREFS = "kiosk_settings";
    private static final String KEY_PIN = "admin_pin";
    private static final String KEY_ALLOWED = "allowed_packages";
    private static final String DEFAULT_PIN = "2468";

    private DevicePolicyManager dpm;
    private ComponentName adminComponent;
    private LinearLayout appsContainer;
    private TextView status;
    private boolean adminMode = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        adminComponent = new ComponentName(this, KioskDeviceAdminReceiver.class);
        status = findViewById(R.id.status);
        appsContainer = findViewById(R.id.appsContainer);

        findViewById(R.id.setupOwner).setOnClickListener(v -> requestDeviceAdmin());
        findViewById(R.id.startKiosk).setOnClickListener(v -> startKiosk());
        findViewById(R.id.admin).setOnClickListener(v -> showAdminPin());
        findViewById(R.id.exit).setOnClickListener(v -> exitWithPin());

        renderApps();
        updateStatus();
    }

    private void updateStatus() {
        boolean owner = dpm.isDeviceOwnerApp(getPackageName());
        status.setText("Device Owner: " + (owner ? "YES" : "NO")
                + "\nAdmin PIN default: 2468 (change it in Admin)");
    }

    private void requestDeviceAdmin() {
        if (dpm.isDeviceOwnerApp(getPackageName())) {
            toast("Already Device Owner.");
            return;
        }
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Enable device admin for this kiosk test app.");
        startActivity(intent);
        toast("Device Admin is not the same as Device Owner. Full kiosk requires Device Owner provisioning.");
    }

    private void startKiosk() {
        if (!dpm.isDeviceOwnerApp(getPackageName())) {
            new AlertDialog.Builder(this)
                    .setTitle("Device Owner required")
                    .setMessage("This app cannot enforce kiosk mode until it is provisioned as Device Owner on a dedicated/managed test device.")
                    .setPositiveButton("OK", null).show();
            return;
        }

        Set<String> packages = getAllowedPackages();
        packages.add(getPackageName());
        dpm.setLockTaskPackages(adminComponent, packages.toArray(new String[0]));
        try {
            dpm.setLockTaskFeatures(adminComponent,
                    DevicePolicyManager.LOCK_TASK_FEATURE_NONE);
        } catch (Exception ignored) { }
        startLockTask();
        toast("Kiosk mode started.");
    }

    private void showAdminPin() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint("Admin PIN");
        new AlertDialog.Builder(this)
                .setTitle("Admin access")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue", (dialog, which) -> {
                    if (getPin().equals(input.getText().toString())) {
                        adminMode = true;
                        showAdminPanel();
                    } else {
                        toast("Wrong PIN.");
                    }
                }).show();
    }

    private void showAdminPanel() {
        EditText pin = new EditText(this);
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setHint("New admin PIN (4-12 digits)");

        new AlertDialog.Builder(this)
                .setTitle("Admin settings")
                .setMessage("You can choose allowed apps from the list below. To change PIN, enter a new one.")
                .setView(pin)
                .setNegativeButton("Done", (d, w) -> { adminMode = false; renderApps(); })
                .setPositiveButton("Save PIN", (d, w) -> {
                    String newPin = pin.getText().toString();
                    if (newPin.length() >= 4 && newPin.length() <= 12) {
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_PIN, newPin).apply();
                        toast("PIN changed.");
                    } else {
                        toast("PIN must be 4-12 digits.");
                    }
                    adminMode = false;
                    renderApps();
                }).show();
        renderApps();
    }

    private void exitWithPin() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint("Admin PIN");
        new AlertDialog.Builder(this)
                .setTitle("Exit kiosk")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Exit", (dialog, which) -> {
                    if (!getPin().equals(input.getText().toString())) {
                        toast("Wrong PIN.");
                        return;
                    }
                    try { stopLockTask(); } catch (Exception ignored) { }
                    toast("Kiosk mode stopped.");
                }).show();
    }

    private String getPin() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PIN, DEFAULT_PIN);
    }

    private Set<String> getAllowedPackages() {
        Set<String> saved = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getStringSet(KEY_ALLOWED, null);
        if (saved == null) return new HashSet<>();
        return new HashSet<>(saved);
    }

    private List<ApplicationInfo> getLaunchableApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> all = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        List<ApplicationInfo> result = new ArrayList<>();
        for (ApplicationInfo info : all) {
            if (pm.getLaunchIntentForPackage(info.packageName) != null
                    && !info.packageName.equals(getPackageName())) {
                result.add(info);
            }
        }
        Collections.sort(result, (a, b) ->
                pm.getApplicationLabel(a).toString().compareToIgnoreCase(
                        pm.getApplicationLabel(b).toString()));
        return result;
    }

    private void renderApps() {
        appsContainer.removeAllViews();
        PackageManager pm = getPackageManager();
        Set<String> allowed = getAllowedPackages();

        for (ApplicationInfo info : getLaunchableApps()) {
            String label = pm.getApplicationLabel(info).toString();

            if (adminMode) {
                CheckBox check = new CheckBox(this);
                check.setText(label + "\n" + info.packageName);
                check.setChecked(allowed.contains(info.packageName));
                check.setPadding(4, 10, 4, 10);
                check.setOnCheckedChangeListener((button, checked) -> {
                    Set<String> now = getAllowedPackages();
                    if (checked) now.add(info.packageName); else now.remove(info.packageName);
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putStringSet(KEY_ALLOWED, now).apply();
                });
                appsContainer.addView(check);
            } else if (allowed.contains(info.packageName)) {
                Button launch = new Button(this);
                launch.setText(label);
                launch.setAllCaps(false);
                launch.setOnClickListener(v -> {
                    Intent launchIntent = pm.getLaunchIntentForPackage(info.packageName);
                    if (launchIntent != null) {
                        try { startActivity(launchIntent); }
                        catch (Exception e) { toast("Could not open " + label); }
                    }
                });
                appsContainer.addView(launch);
            }
        }

        if (!adminMode && allowed.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No apps selected yet. Tap Admin / Allowed Apps, enter PIN 2468, and select apps.");
            empty.setPadding(4, 12, 4, 12);
            appsContainer.addView(empty);
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
